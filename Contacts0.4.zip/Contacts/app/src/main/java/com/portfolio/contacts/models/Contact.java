package com.portfolio.contacts.models;

/**
 * Contact class object
 */

public class Contact {

    private String name;
    private String phoneNumber;
    private String device;
    private String email;
    private String profileImage; //file://documents/images

    public Contact(String name, String phoneNumber, String device, String profileImage) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.device = device;
        this.profileImage = profileImage;
    }

    public String getEmail(){return email;}
    public void setEmail(String email){this.email = email;}
    public String getName(){return name;}
    public void setName(String name){this.name = name;}
    public String getPhoneNumber(){return phoneNumber;}
    public void setPhoneNumber(String phoneNumber){this.phoneNumber = phoneNumber;}
    public String getDevice(){return device;}
    public void setDevice(String device){this.device = device;}
    public String getProfileImage(){return profileImage;}
    public void setProfileImage(String profileImage){this.profileImage = profileImage;}

    @Override
    public String toString() {
        return "Contact{" + "name='" + name + '\'' + ", phoneNumber='" + phoneNumber + '\'' +
                ", device='" + device + '\'' + ", profileImage='" + profileImage + '\'' + '}';
    }
}
