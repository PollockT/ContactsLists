package com.portfolio.contacts;

import android.content.Context;
import android.media.Image;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.ListView;

import com.portfolio.contacts.models.Contact;
import com.portfolio.contacts.utils.CustomListAdapter;

import java.util.ArrayList;

public class ViewListFragment extends Fragment {
    private String imageURL = "photos2.fotosearch.com/bthumb/CSP/CSP881/ninja-mascot-clip-art__k25046218.jpg";

    private static final String TAG = "ViewListFragment";
    private static final int STANDARD = 0;
    private static final int SEARCH = 1;
    private int mActionBarState;

    private AppBarLayout viewContactsBar, searchBar;
    private CustomListAdapter adapter;
    private ListView contactList;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contactslist,container,false);
        viewContactsBar = (AppBarLayout) view.findViewById(R.id.contacts_appbar);
        searchBar = (AppBarLayout) view.findViewById(R.id.search_appBar);
        contactList = (ListView) view.findViewById(R.id.contact_listView);

        Log.d(TAG, "onCreateView: ListView Fragment called");

        setAppBarState(STANDARD); //  start in 0 state

        setupContactList();

        //GOTO fragment for adding contacts
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.floating_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: fab clicked");
            }
        });

        //GOTO fragment for searching
        ImageView search = (ImageView) view.findViewById(R.id.iv_Search_Icon);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: search button clicked");
                toggleToolBarState();
            }
        });

        ImageView ivBackArrow = (ImageView) view.findViewById(R.id.iv_BackArrow);
        ivBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"onClick: back arrow clicked");
                toggleToolBarState();
            }
        });


        return view;
    }

    private void setupContactList(){
        final ArrayList<Contact> contacts = new ArrayList<>();
        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));

        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));
        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));
        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));
        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));
        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));
        contacts.add(new Contact("Theodore Pollock","(614)296-1112","pollock@gmail.com",imageURL));

        adapter = new CustomListAdapter(getActivity(),R.layout.layout_contactlistitem, contacts, "https://");
        contactList.setAdapter(adapter);
    }

    /**
     * initiates the toolbar being toggled
     */
    private void toggleToolBarState() {
        if(mActionBarState == STANDARD){
            setAppBarState(SEARCH);
        }else{
            setAppBarState(STANDARD);
        }
    }

    /**
     * changes the tool bar state to either standard or search
     * @param standard
     */
    private void setAppBarState(int standard) {
        Log.d(TAG,"setAppBarState: changing app bar state");

        mActionBarState = standard;

        if(mActionBarState == STANDARD){
            searchBar.setVisibility(View.GONE);
            viewContactsBar.setVisibility(View.VISIBLE);
            Log.d(TAG,"action bar set at standard");

            //hide the keyboard if open
            View view = getView();
            InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            try{
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(),0);
            } catch (NullPointerException e){
                Log.d(TAG,"setAppBarState: Nullpointer Exeception Flagged!" + e.getLocalizedMessage());
            }

        }else if(mActionBarState == SEARCH){
            viewContactsBar.setVisibility(View.GONE);
            searchBar.setVisibility(View.VISIBLE);
            Log.d(TAG,"action bar set to search");

            //open keyboard if not open
            InputMethodManager inputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        setAppBarState(STANDARD);
    }

}
