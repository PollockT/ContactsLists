package com.portfolio.contacts.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Contact class object
 */

public class Contact implements Parcelable {

    private String name;
    private String phoneNumber;
    private String device;
    private String email;
    private String profileImage; //file://documents/images

    public Contact(String name, String phoneNumber, String device, String email, String profileImage) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.device = device;
        this.email = email;
        this.profileImage = profileImage;
    }

    protected Contact(Parcel in) {
        name = in.readString();
        phoneNumber = in.readString();
        device = in.readString();
        email = in.readString();
        profileImage = in.readString();
    }

    public static final Creator<Contact> CREATOR = new Creator<Contact>() {
        @Override
        public Contact createFromParcel(Parcel in){return new Contact(in);}

        @Override
        public Contact[] newArray(int size){return new Contact[size];}
    };

    public String getEmail(){return email;}
    public void setEmail(String email){this.email = email;}
    public String getName(){return name;}
    public void setName(String name){this.name = name;}
    public String getPhoneNumber(){return phoneNumber;}
    public void setPhoneNumber(String phoneNumber){this.phoneNumber = phoneNumber;}
    public String getDevice(){return device;}
    public void setDevice(String device){this.device = device;}
    public String getProfileImage(){return profileImage;}
    public void setProfileImage(String profileImage){this.profileImage = profileImage;}

    @Override
    public String toString() {
        return "Contact{" +
                "name= '" + name + '\'' +
                ", phoneNumber= '" + phoneNumber + '\'' +
                ", device= '" + device + '\'' +
                ", email= '" + email + '\'' +
                ", profileImage= '" + profileImage + '\'' +
                '}';
    }

    /**
     * Describe the kinds of special objects contained in this Parcelable
     * instance's marshaled representation. For example, if the object will
     * include a file descriptor in the output of {@link #writeToParcel(Parcel, int)},
     * the return value of this method must include the
     * {@link #CONTENTS_FILE_DESCRIPTOR} bit.
     *
     * @return a bitmask indicating the set of special object types marshaled
     * by this Parcelable object instance.
     */
    @Override
    public int describeContents(){return 0;}

    /**
     * Flatten this object in to a Parcel.
     *
     * @param dest  The Parcel in which the object should be written.
     * @param flags Additional flags about how the object should be written.
     *              May be 0 or {@link #PARCELABLE_WRITE_RETURN_VALUE}.
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(phoneNumber);
        dest.writeString(device);
        dest.writeString(email);
        dest.writeString(profileImage);
    }
}
