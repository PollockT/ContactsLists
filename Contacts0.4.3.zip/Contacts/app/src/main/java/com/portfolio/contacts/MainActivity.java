package com.portfolio.contacts;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.nostra13.universalimageloader.core.ImageLoader;
import com.portfolio.contacts.models.Contact;
import com.portfolio.contacts.utils.UniversalImageLoader;

public class MainActivity extends AppCompatActivity implements ViewListFragment.OnContactSelectedListener {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        initializeImageLoader();
    }

    /**
     * first fragment getting called
     */
    private void initialize(){
        ViewListFragment fragment = new ViewListFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container,fragment);//Fragment replacer!!
        transaction.addToBackStack(null);
        transaction.commit();
        Log.d(TAG, "initialize: called, fragment made");
    }

    private void initializeImageLoader(){
        UniversalImageLoader universalImageLoader = new UniversalImageLoader(MainActivity.this);
        ImageLoader.getInstance().init(universalImageLoader.grabConfig());
    }

    @Override
    public void OnContactSelected(Contact contact) {
        Log.d(TAG, "OnContactSelected: interface received: " + getString(R.string.view_contact_fragment));

        ContactFragment fragment = new ContactFragment();
        Bundle args = new Bundle();
        args.putParcelable(getString(R.string.contact),contact);
        fragment.setArguments(args);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(getString(R.string.contact_fragment));
        transaction.commit();
    }
}

