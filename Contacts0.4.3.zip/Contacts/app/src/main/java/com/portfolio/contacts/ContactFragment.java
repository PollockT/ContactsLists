package com.portfolio.contacts;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.portfolio.contacts.models.Contact;
import com.portfolio.contacts.utils.UniversalImageLoader;

import de.hdodenhof.circleimageview.CircleImageView;

public class ContactFragment extends Fragment {
    private static final String TAG = "Contact";

    private Toolbar toolbar;
    private Contact mContact;
    private TextView mName;
    private CircleImageView mImage;


    public ContactFragment(){
        super();
        setArguments(new Bundle());
    }

    @Nullable
    @Override


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact,container,false);
        Log.d(TAG,"onCreateView method \n Contact Details Fragment Called ");
        mContact = getContactFromBundle();
        mName = (TextView) view.findViewById(R.id.contact_name);
        mImage = (CircleImageView) view.findViewById(R.id.contact_image);
        
        if(mContact != null){
            Log.d(TAG, "onCreateView: received contact " + mContact.getName());
        }

        //toolbar create
        toolbar = (Toolbar) view.findViewById(R.id.contactToolbar);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        setHasOptionsMenu(true);

        //back arrow navigation
        ImageView ivBackArrow = (ImageView) view.findViewById(R.id.iv_BackArrow);
        ivBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"onClick: back arrow clicked");

                //removing previous activity from the back of the stack w/ .popBackStack()
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        //edit button navigation
        ImageView ivEdit = (ImageView) view.findViewById(R.id.iv_edit_button);
        ivEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"onClick: edit button clicked");

                Log.d(TAG,"onClick: moved to edit contact fragment");

            }
        });

        initialize ();
        return view;
    }

    private void initialize (){
        mContact.setName(mContact.getName());
        UniversalImageLoader.setImage(mContact.getProfileImage(),mImage,null,"http://");

    }

    //menu create
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.contact_menu,menu);
        Log.d(TAG,"onCreateOptionsMenu: Menu icon clicked");
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.d(TAG,"Item clicked on from menu");
        switch(item.getItemId()){
            case R.id.action_menu_delete:
                Log.d(TAG, "onOptionsItemSelected: item deleted");
        }
        return super.onOptionsItemSelected(item);
    }

    private Contact getContactFromBundle(){
        Log.d(TAG, "getContactFromBundle: bundle info received: " + getArguments());

        Bundle bundle = this.getArguments();
        if(bundle != null){
            return bundle.getParcelable(getString(R.string.contact));
        }else{
            return null;
        }
    }
}
