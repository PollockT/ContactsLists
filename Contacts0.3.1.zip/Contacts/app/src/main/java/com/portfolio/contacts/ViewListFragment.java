package com.portfolio.contacts;

import android.media.Image;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class ViewListFragment extends Fragment {
    private static final String TAG = "ViewListFragment";
    private static final int STANDARD = 0;
    private static final int SEARCH = 1;
    private int mActionBarState;

    private AppBarLayout viewContactsBar, searchBar;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contactslist,container,false);
        viewContactsBar = (AppBarLayout) view.findViewById(R.id.contacts_appbar);
        searchBar = (AppBarLayout) view.findViewById(R.id.search_appBar);

        Log.d(TAG, "onCreateView: ListView Fragment called");

        //GOTO fragment for adding contacts
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.floating_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: fab clicked");
            }
        });

        //GOTO fragment for searching
        ImageView search = (ImageView) view.findViewById(R.id.iv_Search_Icon);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: search button clicked");
                toggleToolBarState();
            }
        });

        ImageView ivBackArrow = (ImageView) view.findViewById(R.id.iv_BackArrow);
        ivBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG,"onClick: back arrow clicked");
                toggleToolBarState();
            }
        });


        return view;
    }

    private void toggleToolBarState() {
        if(mActionBarState == STANDARD){
            setAppBarState(SEARCH);
        }else{
            setAppBarState(STANDARD);
        }
    }

    private void setAppBarState(int standard) {
        Log.d(TAG,"setAppBarState: changing app bar state");

        mActionBarState = standard;

        if(mActionBarState == STANDARD){
            searchBar.setVisibility(View.GONE);
            viewContactsBar.setVisibility(View.VISIBLE);
        }else if(mActionBarState == SEARCH){
            viewContactsBar.setVisibility(View.GONE);
            searchBar.setVisibility(View.VISIBLE);
        }
    }
}
