package com.portfolio.contacts;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

    /**
     * first fragment getting called
     */
    private void initialize(){
        ViewListFragment fragment = new ViewListFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container,fragment);//Fragment replacer!!
        transaction.addToBackStack(null);
        transaction.commit();
        Log.d(TAG, "initialize: called, fragment made");
    }
}
